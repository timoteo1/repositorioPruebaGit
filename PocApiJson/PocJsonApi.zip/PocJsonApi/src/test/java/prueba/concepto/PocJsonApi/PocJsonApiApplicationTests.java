package prueba.concepto.PocJsonApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PocJsonApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
