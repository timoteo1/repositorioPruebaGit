package prueba.concepto.PocJsonApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PocJsonApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PocJsonApiApplication.class, args);
	}

}
